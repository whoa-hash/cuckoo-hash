****
This is freely-available version of Julius.
This version does not contain Julian (Grammar-based recognizer).
****
Please read doc/index.html (in Japanese)
For English documentation, see Julius-3.2-book-e.pdf, and online manuals.
