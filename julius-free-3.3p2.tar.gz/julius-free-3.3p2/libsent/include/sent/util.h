/* Copyright (c) 1991-2002 Doshita Lab. Speech Group, Kyoto University */
/* Copyright (c) 2000-2002 Speech and Acoustics Processing Lab., NAIST */
/*   All rights reserved   */

/* util.h --- misc. utility functions in util/ */

/* $Id: util.h,v 1.4 2002/10/15 07:17:46 ri Exp $ */

#ifndef __SENT_UTIL_H__
#define __SENT_UTIL_H__

/*
 *  Memory block size for mybmalloc() in bytes.
 *  mybmalloc does allocate memory per big block, though cannot free.
 *  It's for reading in large data (i.e. models).
 */
#define MYBMALLOC_BLOCK_SIZE 10000

typedef struct __bmalloc_base__ {
  void *base;			/* pointer to the malloced block */
  char *now, *end;		/* current point */
  struct __bmalloc_base__ *next;
} BMALLOC_BASE;

/* readfile.c */
char *getl(char *, int, FILE *);
char *getl_fd(char *, int, int);
char *first_token(char *);
char *next_token(void);
char *next_token_if_any(void);
char *rest_token(void);

/* gzfile.c */
FILE *fopen_readfile(char *);
int fclose_readfile(FILE *);
FILE *fopen_writefile(char *);
int fclose_writefile(FILE *);
size_t myfread(void *ptr, size_t size, size_t n, FILE *fp);
size_t myfwrite(void *ptr, size_t size, size_t n, FILE *fp);

/* mybmalloc.c */
void mybmalloc_set_param();
void *mybmalloc(int);
char *mybstrdup(char *);
void *mybmalloc2(int size, BMALLOC_BASE **list);
void mybfree2(BMALLOC_BASE **list);

/* mymalloc.c */
void *mymalloc(int);
void *myrealloc(void *, int);
void *mycalloc(int, int);

/* endian.c */
void swap_sample_bytes(short *buf, int len);
void swap_bytes(char *buf, size_t unitbyte, int unitnum);

/* j_printf.c */
#include <stdarg.h>
int j_printf(char *format, ...);
int j_printerr(char *format, ...);
int j_flushprint();
int j_error(char *format, ...);
void j_error_register_exitfunc(void (*error_func)());
int j_exit();
void j_exit_register_exitfunc(void (*exit_func)());

/* mystrtok.c */
char  *mystrtok_quotation(char *str, char *delim, int left_paren, int right_paren, int mode); /* mode:0=normal, 1=just move to next token */
char *mystrtok_quote(char *str, char *delim);
char *mystrtok(char *str, char *delim);
char *mystrtok_movetonext(char *str, char *delim);

#endif /* __SENT_UTIL_H__ */
