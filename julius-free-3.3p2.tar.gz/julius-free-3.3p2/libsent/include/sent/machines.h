/* Copyright (c) 1991-2002 Doshita Lab. Speech Group, Kyoto University */
/* Copyright (c) 2000-2002 Speech and Acoustics Processing Lab., NAIST */
/*   All rights reserved   */

/* machines.h --- architecture-dependant definition */

/* $Id: machines.h,v 1.2 2002/09/11 22:01:50 ri Exp $ */

#ifndef __SENT_MACHINES_H__
#define __SENT_MACHINES_H__

/*
#ifndef strcasecmp
int strcasecmp(char *s1, char *s2);
int strncasecmp(char *s1, char *s2, size_t n);
#endif
*/

#endif /* __SENT_MACHINES_H__ */
