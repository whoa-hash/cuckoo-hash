/* Copyright (c) 2002 Speech and Acoustics Processing Lab., NAIST */
/*   All rights reserved   */

#include "japi.h"

void
japi_die(int sd)
{
  do_send(sd, "DIE\n");
}
void
japi_get_version(int sd)
{
  do_send(sd, "VERSION\n");
}
void
japi_get_status(int sd)
{
  do_send(sd, "STATUS\n");
}
void
japi_pause_recog(int sd)
{
  do_send(sd, "PAUSE\n");
}
void
japi_terminate_recog(int sd)
{
  do_send(sd, "TERMINATE\n");
}
void
japi_resume_recog(int sd)
{
  do_send(sd, "RESUME\n");
}
void
japi_set_input_handler_on_change(int sd, char *arg)
{
  char *p;

  /* argument should be checked here... */
  /* one of TERMINATE, PAUSE, WAIT */

  /* send */
  do_sendf(sd, "INPUTONCHANGE\n%s\n", arg);
}
