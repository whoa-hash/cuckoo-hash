#!/usr/bin/perl
#
# insert header
#
# $Id: insertheader.pl,v 1.4 2001/08/17 09:40:10 ri Exp $

while(<>) {
    if (/<head>/) {
	print <<'EOF';
<meta http-equiv="Content-Type" content="text/html; charset="ISO-2022-JP">
<link rel="stylesheet" type="text/css" href="default.css">
EOF
    }
    print;
}
