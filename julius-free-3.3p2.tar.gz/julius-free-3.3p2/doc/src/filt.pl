#!/usr/bin/perl
#
# post process
# 
# $Id: filt.pl,v 1.5 2001/08/17 09:40:07 ri Exp $

while(<>) {
#    s/<address>.*<\/address>/<a href=\"mailto:julius\@kuis\.kyoto-u\.ac\.jp\"><address>julius\@kuis\.kyoto-u\.ac\.jp<\/address><\/a>/g;
    chop;
    if (/\$Id:\s[^\s]+\s[^\s]+\s([^\s]+)\s([^\s]+)\s[^\s]+\s[^\s]+/) {
	print "<small><i>Last modified: $1 $2</i></small>\n";
	next;
    }
    print "$_\n";
}
