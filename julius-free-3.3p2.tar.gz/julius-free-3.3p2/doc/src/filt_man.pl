#!/usr/bin/perl
#
# post process for manual
# 
# $Id: filt_man.pl,v 1.4 2002/09/11 21:00:39 ri Exp $

$body = 0;
$manual = 0;
$manual_body = 0;

while(<>) {
#    s/<address>.*<\/address>/<a href=\"mailto:julius\@kuis\.kyoto-u\.ac\.jp\"><address>julius\@kuis\.kyoto-u\.ac\.jp<\/address><\/a>/g;
    if (/<\!\-\- manual \-\->/) {
	$manual = 1;
    }
    if ($manual == 1) {
	if (/<body>/) {
	    $body = 1;
	}
	if (/<pre>/) {
	    if ($body == 1) {
		$manual_body = 1;
		$body = 0;
	    }
	}
	if (/<\/pre>/) {
	    $manual_body = 0;
	}
    }

    if ($manual_body == 1) {
	if (/^[^\<\s]/) {
	    chop;
	    $sec = $_;
	    print "<h3>$sec</h3>\n";
	} else {
	    print;
	}
    } else {
	if (/\$Id:\s[^\s]+\s[^\s]+\s([^\s]+)\s([^\s]+)\s[^\s]+\s[^\s]+/) {
	    print "<small><i>Last modified: $1 $2</i></small>\n";
	    next;
	}
	print;
    }
}
