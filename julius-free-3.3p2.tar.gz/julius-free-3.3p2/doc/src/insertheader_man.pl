#!/usr/bin/perl
#
# insert header
#
# $Id: insertheader_man.pl,v 1.3 2001/08/17 09:40:11 ri Exp $

while(<>) {
    if (/<head>/) {
	print <<'EOF';
<meta http-equiv="Content-Type" content="text/html; charset="ISO-2022-JP">
<link rel="stylesheet" type="text/css" href="man.css">
EOF
    }
    print;
}
