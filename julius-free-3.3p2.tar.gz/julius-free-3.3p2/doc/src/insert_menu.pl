#!/usr/bin/perl
#
# post process for index
# 
# $Id: insert_menu.pl,v 1.1 2001/08/16 19:22:37 ri Exp $

$menu = $ARGV[0];
while(<STDIN>) {
    print;
    if (/<noframe>/) {
	print "<hr>\n";
	open(MENU, "$menu") || die "cannot open menu\n";
	while(<MENU>) {
	    last if (/<body>/);
	}
	while(<MENU>) {
	    last if (/<\/body>/);
	    print;
	}
	close(MENU);
    }
}
