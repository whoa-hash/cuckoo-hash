#!/bin/sh
#
# make jman.txt and jman.txt.ps from jman
#
nroff -Tnippon -man $1 > $1.txt
man -Tps -l $1 > $1.txt.ps
