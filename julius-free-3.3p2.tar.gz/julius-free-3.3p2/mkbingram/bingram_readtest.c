/* Copyright (c) 1991-2002 Doshita Lab. Speech Group, Kyoto University */
/* Copyright (c) 2000-2002 Speech and Acoustics Processing Lab., NAIST */
/*   All rights reserved   */

/* mkbingram --- make binary n-gram for JULIUS from ARPA standard format */

#include <sent/stddefs.h>
#include <sent/ngram2.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

NGRAM_INFO ngram;


int
main(int argc, char *argv[])
{
  int i;
  int fd;

  if (argc < 2) {
    P_ERROR("\tusage:  %s bingram_file\n", argv[0]);
    return -1;
  }
  
  /* read in ARPA n-gram */
  init_ngram_bin(&ngram, argv[1]);
  return 0;
}
