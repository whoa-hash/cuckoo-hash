/* Copyright (c) 1991-2002 Doshita Lab. Speech Group, Kyoto University */
/* Copyright (c) 2000-2002 Speech and Acoustics Processing Lab., NAIST */
/*   All rights reserved   */

/* factoring_sub.c --- functions to build successor tree and compute factoring value */

/* $Id: factoring_sub.c,v 1.8 2002/09/11 22:02:33 ri Exp $ */

/* for Julius (N-gram) : 2-gram factoring, 1-gram factoring implemented
   for Julian (grammar): deterministic factoring implemented
                         (when CATEGORY_TREE not defined)
			 
   default: 1-gram factoring for Julius, category-tree lexicon (deterministic
   factoring not used) for Julian
*/

#include <julius.h>

#ifndef CATEGORY_TREE		/* category tree does not need factoring */

/*----------------------------------------------------------------------*/
/* successor list:

   $BLZ9=B$2=<-=q$N3F%N!<%I$K3d$jIU$1$i$l$k!$$=$N%N!<%I6&M-C18l$N%j%9%H!%(B
   $B;^J,$+$l$7$?:G=i$N%N!<%I$N$_$,;}$D!%(B
   Lists of words sharing the node, assigned to each lexicon tree node.
   Only the nodes just after the branch have this.
   

          2-o-o - o-o-o - o-o-o          word "A" 
         /
    1-o-o
	 \       4-o-o                   word "B"
	  \     /   
	   3-o-o - 5-o-o - 7-o-o         word "C"
	        \        \ 
		 \        8-o-o          word "D"
		  6-o-o                  word "E"
		   

    node  | successor list (wchmm->state[node].sc)
    =======================
      1   | A B C D E
      2   | A
      3   |   B C D E
      4   |   B
      5   |     C D
      6   |         E
      7   |     C
      8   |       D

   $BCmL\(B: $B>e5-$NC18l(B "A" $B$N>l9g(B,$B8@8l%9%3%"$OC18l=*C<$G$O$J$/%N!<%I(B 2 $B$N0LCV$G(B
   $B4{$K3NDj$9$k!%(B
   Notice: language score for word "A" is determined in node 2 (not word end).

*/

/* $BBh#1%Q%9$K$*$1$k(Bfactoring $B$N<B9T(B: $B<B:]$K$O(B beam.c $B$G9T$J$o$l$k(B

   2-gram factoring: 
   $B!V<!%N!<%I$K(B successor list $B$,B8:_$9$l$P(B, $B$=$N(B successor list $B$NC18l$N(B
     2-gram $B$N:GBgCM$r5a$a$F(B, $BEAHB$7$F$-$F$$$k(Bfactoring $BCM$r99?7$9$k!W(B
     $B"*(Bsuccessor list 1$B$D$NC18l3NDj%N!<%I$G$O<+F0E*$K@5$7$$(B2-gram$B$,3d$jEv$?$k(B

   1-gram factoring:
   $B!V<!%N!<%I$K(B successor list $B$,B8:_$9$l$P(B, $B$=$N(B successor list $B$NC18l$N(B
     1-gram $B$N:GBgCM$r5a$a$F!$EAHB$7$F$-$F$$$k(Bfactoring $BCM$r99?7$9$k!W(B
     $B"*C18l3NDj%N!<%I$G$O(B2-gram $B$r7W;;(B

     $B9bB.2=$H8zN(2=(B: 1-gram $B$N:GBgCM$O%3%s%F%-%9%HHs0MB8(B: $B5/F0;~$KA4It7W;;$7$F(B
     wchmm->state[node].fscore $B$K3JG<$7$F$*$-!$$=$N(B successor list $B$O(B free $B$9$k(B

   DFA$BJ8K!;HMQ;~$N7hDjE*(B factoring (CATEGORY_TREE $B$,(B undefined $B$N>l9g(B):
   $B!V<!%N!<%I$K(B successor list $B$,B8:_$9$l$P(B, $B$=$N(B successor list $BFb$N(B
     $BC18l$N%+%F%4%j$rD4$Y(B, $B0l$D$G$bD>A0C18l$H%+%F%4%jBP@)Ls>e@\B32DG=$J(B
     $BC18l$,$"$l$P!$A+0\$r5v$9!%0l$D$b$J$1$l$PA+0\$5$;$J$$!W(B
*/

/* factoring execution in Viterbi: mainly operated in beam.c

   2-gram factoring:
   "If successor list exist in the next node, compute the maximum 2-gram
    likelihood of the successor list and update the factoring value."
    -> precise 2-gram will be automatically assigned at the node with single
       successor word.

   1-gram factoring:
   "If successor list exist in the next node, get the maximum 1-gram
    likelihood of the successor list and update the factoring value.
    If the next node has only one successor word, update the factoring value
    with true 2-gram."
    For efficiency, 1-gram factoring value (independent of the hypothesis) for
    each successor list is computed before search.  They are stored in
    wchmm->state[node].fscore.

   DFA deterministic factoring (in case Julian and CATEGORY_TREE undefined):
   "If successor list exist in the next node, allow transition only if there
   is any word that can connect to the previous word hypothesis."
   
*/
		  
/*----------------------------------------------------------------------*/
/* successor list $B$r9=C[$9$k!%(B
   $BC18l$N(B ID $B$O(B N-gram $B$G$NHV9f(B($B$"$k$$$O%+%F%4%jHV9f(B), $B<-=q$NC18l(BID$B$G$J$$(B
   $B$3$H$KCm0U!%C18l$O(BID$B$G>:=g$KJ]B8$9$k(B */
/* build whole successor lists.
   IDs in the lists are those of N-gram entry, not word ID in dictionary.
   Words in lists should be ordered by ID. */

/* add word 'w' to successor list at 'node' (w = dictionary ID) */
static void
add_successor(WCHMM_INFO *wchmm, int node, WORD_ID w)
{
  S_CELL *sctmp, *sc;

  /* malloc new */
  sctmp=(S_CELL *) mymalloc(sizeof(S_CELL));
  if (sctmp == NULL) {
    j_error("malloc fault at add_succesor(%d,%d)\n",node,w);
  }
  /* assign word ID */
  sctmp->word = wchmm->winfo->wton[w];
  /* add to list (keeping order) */
  sc = wchmm->state[node].sc;
  if (sc == NULL || sctmp->word < sc->word) {
    sctmp->next = sc;
    wchmm->state[node].sc = sctmp;
  } else {
    for(;sc;sc=sc->next) {
      if (sc->next == NULL || sctmp->word < (sc->next)->word) {
	if (sctmp->word == sc->word) break; /* avoid duplication */
	sctmp->next = sc->next;
	sc->next = sctmp;
	break;
      }
    }
  }
}

/* check if successor lists in 'node1' and 'node2' are the same */
static boolean
match_successor(WCHMM_INFO *wchmm, int node1, int node2)
{
  S_CELL *sc1,*sc2;

  /* assume successor is sorted by ID */
  sc1 = wchmm->state[node1].sc;
  sc2 = wchmm->state[node2].sc;
  for (;;) {
    if (sc1 == NULL || sc2 == NULL) {
      if (sc1 == NULL && sc2 == NULL) {
	return TRUE;
      } else {
	return FALSE;
      }
    } else if (sc1->word != sc2->word) {
      return FALSE;
    }
    sc1 = sc1->next;
    sc2 = sc2->next;
  }
}

/* free successor list at 'node' */
static void
free_successor(WCHMM_INFO *wchmm, int node)
{
  S_CELL *sc;
  S_CELL *sctmp;

  sc = wchmm->state[node].sc;
  while (sc != NULL) {
    sctmp = sc;
    sc = sc->next;
    free(sctmp);
  }
  wchmm->state[node].sc = NULL;
}

/* main function to build whole successor list to lexicon tree 'wchmm' */
void
make_successor_list(WCHMM_INFO *wchmm)
{
  int node;
  WORD_ID w;
  int i;
  int freed_num = 0;
  boolean *freemark;

  VERMES("  make successor lists for factoring...");

  /* 1. initialize */
  freemark = (boolean *)mymalloc(sizeof(boolean) * wchmm->n);
  for (node=0;node<wchmm->n;node++) {
    wchmm->state[node].sc = NULL;
    freemark[node] = FALSE;
  }

  /* 2. make initial successor list: assign at all possible nodes */
  for (w=0;w<wchmm->winfo->num;w++) {
    /* at each start node of phonemes */
    for (i=0;i<wchmm->winfo->wlen[w];i++) {
      add_successor(wchmm, wchmm->offset[w][i], w);
    }
    /* at word end */
    add_successor(wchmm, wchmm->wordend[w], w);
  }
  
  /* 3. erase unnecessary successor list */
  /* sucessor list same as the previous node is not needed, so */
  /* parse lexicon tree from every leaf to find the same succesor list */
  for (w=0;w<wchmm->winfo->num;w++) {
    node = wchmm->wordend[w];	/* begin from the word end node */
    i = wchmm->winfo->wlen[w]-1;
    while (i >= 0) {		/* for each phoneme start node */
      if (node == wchmm->offset[w][i]) {
	/*	printf("same:w=%d,phoneloc=%d,node=%d,%d\n", w, i, wchmm->offset[w][i], node);
	{
	  S_CELL *sc;
	  for(sc=wchmm->state[node].sc;sc;sc=sc->next) {
	    printf("%d[%s],", sc->word, ngram->wname[sc->word]);
	  }
	  printf("\n");
	  }*/
	/* word with only 1 state: skip */
	i--;
	continue;
      }
      if (match_successor(wchmm, node, wchmm->offset[w][i])) {
	freemark[node] = TRUE;	/* mark the node */
      }
/* 
 *	 if (freemark[wchmm->offset[w][i]] != FALSE) {
 *	   break;
 *	 }
 */
      node = wchmm->offset[w][i];
      i--;
    }
  }
  /* really free */
  for (node=0;node<wchmm->n;node++) {
    if (freemark[node] == TRUE) {
      freed_num++;
      free_successor(wchmm, node);
    }
  }

  if (debug2_flag) {
    j_printerr("%d freed...", freed_num);
  }

  free(freemark);

  VERMES("done\n");
}

/* make index to factoring node, and make mapping from node ID
   for factoring cache */
void
make_sc_index(WCHMM_INFO *wchmm)
{
  int n = 0, node;
  wchmm->state2scid = (int *)mymalloc(sizeof(int) * wchmm->n);
  for (node=0;node<wchmm->n;node++) {
    wchmm->state2scid[node] = (wchmm->state[node].sc != NULL) ? n++ : -1;
  }
  wchmm->scnum = n;
}


/* -------------------------------------------------------------------- */
/* factoring computation */

#ifdef USE_NGRAM

/* word-internal factoring value cache:
   a branch node (that has successor list) will keep the factoring value
   on search, and re-use it if incoming token in the next frame has the
   same word context.
 */
static LOGPROB *probcache;	/* cached value: indexed by scid */
static WORD_ID *lastwcache;	/* cached lastword: indexed by scid*/
/* cross-word factoring value cache:
   when computing cross-word transition, (1)factoring values on all word
   start nodes should be computed for each word end, and thus (2)each start
   node has more than one transition within a frame.  So factoring value
   is better cached by the word end (last word) than by nodes.
 */
static LOGPROB **iw_sc_cache;
static int iw_cache_num;
#ifdef HASH_CACHE_IW
static WORD_ID *iw_lw_cache;
#endif
/* once initialized on startup, the factoring value caches will not be
   cleared */

/* initialize factoring cache (once on startup) */
void
max_successor_cache_init(WCHMM_INFO *wchmm)
{
  int i;

  /* for word-internal */
  probcache = (LOGPROB *) mymalloc(sizeof(LOGPROB) * wchmm->scnum);
  lastwcache = (WORD_ID *) mymalloc(sizeof(WORD_ID) * wchmm->scnum);
  for (i=0;i<wchmm->scnum;i++) {
    lastwcache[i] = WORD_INVALID;
  }
  /* for cross-word */
#ifdef HASH_CACHE_IW
# ifdef CLASS_NGRAM
  iw_cache_num = true_max_num * iw_cache_rate / 100;
# else
  iw_cache_num = wchmm->ngram->max_word_num * iw_cache_rate / 100;
# endif
  if (iw_cache_num < 10) iw_cache_num = 10;
#else
# ifdef CLASS_NGRAM
  iw_cache_num = true_max_num;
# else
  iw_cache_num = wchmm->ngram->max_word_num;
# endif
#endif /* HASH_CACHE_IW */
  iw_sc_cache = (LOGPROB **)mymalloc(sizeof(LOGPROB *) * iw_cache_num);
  for (i=0;i<iw_cache_num;i++) {
    iw_sc_cache[i] = NULL;
  }
#ifdef HASH_CACHE_IW
  iw_lw_cache = (WORD_ID *)mymalloc(sizeof(WORD_ID) * iw_cache_num);
  for (i=0;i<iw_cache_num;i++) {
    iw_lw_cache[i] = WORD_INVALID;
  }
#endif
}

/* free cross-word factoring cache */
static void
max_successor_prob_iw_free()
{
  int i;
  for (i=0;i<iw_cache_num;i++) {
    if (iw_sc_cache[i] != NULL) free(iw_sc_cache[i]);
    iw_sc_cache[i] = NULL;
  }
}

/* free word-internal factoring cache */
void
max_successor_cache_free()
{
  free(probcache);
  free(lastwcache);
  max_successor_prob_iw_free();
  free(iw_sc_cache);
#ifdef HASH_CACHE_IW
  free(iw_lw_cache);
#endif
}

#ifdef UNIGRAM_FACTORING

/* 1-gram factoring $B$OD>A0C18l$K1F6A$5$l$J$$$N$G!$(B
   $B@hF,%N!<%I$,(B(unigram$B$N:GBgCM$rM?$($k(B) factoring $B%N!<%I$G$"$k$J$i(B
   $B$=$3$rC18l4V(B LM $B%-%c%C%7%e$9$kI,MW$O$J$$(B
   $B$h$C$F!$(Bfactoring $B%N!<%I$G$J$$@hF,%N!<%I$@$1%-%c%C%7%e$9$k(B */
/* In 1-gram factoring, the factoring values are constant in branch (not leaf)
   nodes.  So, in cross-word factoring, the word start node that is branch
   (shared, not leaf) nodes are not need to be cached. */
void
make_iwcache_index(WCHMM_INFO *wchmm)
{
  int i, node, num;

  wchmm->start2isolate = (int *)mymalloc(sizeof(int) * wchmm->startnum);
  num = 0;
  for(i=0;i<wchmm->startnum;i++) {
    node = wchmm->startnode[i];
    if (wchmm->state[node].fscore == LOG_ZERO) {	/* not a factoring node (isolated node, has no 1-gram factoring value) */
      wchmm->start2isolate[i] = num;
      num++;
    } else {			/* factoring node (shared) */
      wchmm->start2isolate[i] = -1;
    }
  }
  wchmm->isolatenum = num;
}

/* 1-gram factoring$BCM!J8GDj!K$r7W;;$7$F3JG<$9$k!%(B
   $BC5:wA0$K0lEYFI$s$G$*$1$P$h$$!%(B
   $B7W;;BP>]$O(B 1$B0J>e$N(Bsuccessor word $B$r;}$D!aKvC<$G$J$$%N!<%I!%(B
   $B7W;;8e$O$=$3$N(Bsc$B$OI,MW$J$/$J$k$N$G%U%j!<$9$k(B */
/* compute constant 1-gram factoring value for each factoring node.
   should be called once on startup.
   factoring node: has more than one successor word.
   after computation, the successor list will be freed.
 */
void
calc_all_unigram_factoring_values(WCHMM_INFO *wchmm)
{
  S_CELL *sc, *sctmp;
  LOGPROB tmpprob, maxprob;
  int n;

  for (n=0;n<wchmm->n;n++) {
    wchmm->state[n].fscore = LOG_ZERO; /* initial "undefined" value */
    sc = wchmm->state[n].sc;
    if (sc != NULL) {		/* leave undefined if no successor list */
      if (sc->next == NULL) {
	/* only one successor = not factoring node (=leaf node) */
      } else {
	/* compute maximum 1-gram probability in successor words */
	/* and set to fscore */
	maxprob = LOG_ZERO;
	for (sctmp = sc; sctmp; sctmp = sctmp->next) {
#ifdef CLASS_NGRAM
	  tmpprob = class_uni_prob(wchmm->ngram, sctmp->word);
#else
	  tmpprob = uni_prob(wchmm->ngram, sctmp->word);
#endif
	  if (maxprob < tmpprob) maxprob = tmpprob;
	}
	wchmm->state[n].fscore = maxprob;
	free_successor(wchmm, n);
      }
    }
  }
}

#else  /* ~UNIGRAM_FACTORING */

/* compute 2-gram factoring value for the node and return the value */
static LOGPROB
calc_successor_prob(WCHMM_INFO *wchmm, WORD_ID last_nword, int node)
{
  S_CELL *sc;
  LOGPROB tmpprob, maxprob;

  maxprob = LOG_ZERO;
  for (sc = wchmm->state[node].sc; sc; sc = sc->next) {
#ifdef CLASS_NGRAM
    tmpprob = class_bi_prob_lr(wchmm->ngram, last_nword, sc->word);
#else
    tmpprob = bi_prob_lr(wchmm->ngram, last_nword, sc->word);
#endif
    if (maxprob < tmpprob) maxprob = tmpprob;
  }
  return(maxprob);
}

#endif  /* ~UNIGRAM_FACTORING */

/* $B%N!<%I$KBP1~$9$k(Bfactoring$BCM$rJV$9(B($BC18lFb(B) */
/* For word-internal: return factoring value on node "node" with previous
   word "lastword", consulting cache. */
LOGPROB
max_successor_prob(WCHMM_INFO *wchmm, WORD_ID lastword, int node)
{
  LOGPROB maxprob;
  WORD_ID last_nword;
  int scid;

  if (lastword != WORD_INVALID) { /* return nothing if no previous word */
    last_nword = wchmm->winfo->wton[lastword];
#ifdef UNIGRAM_FACTORING
    if (wchmm->state[node].fscore != LOG_ZERO) {
      /* return 1-gram factoring value already calced */
      return(wchmm->state[node].fscore);
    } else {
      scid = wchmm->state2scid[node];
      /* return precise 2-gram score */
      if (last_nword != lastwcache[scid]) {
	/* calc and cache */
#ifdef CLASS_NGRAM
	maxprob = class_bi_prob_lr(wchmm->ngram, last_nword, (wchmm->state[node].sc)->word);
#else
	maxprob = bi_prob_lr(wchmm->ngram, last_nword, (wchmm->state[node].sc)->word);
#endif
	lastwcache[scid] = last_nword;
	probcache[scid] = maxprob;
	return(maxprob);
      } else {
	/* return cached */
	return (probcache[scid]);
      }
    }
#else  /* UNIGRAM_FACTORING */
    /* 2-gram */
    scid = wchmm->state2scid[node];
    if (last_nword != lastwcache[scid]) {
      maxprob = calc_successor_prob(wchmm, last_nword, node);
      /* store to cache */
      lastwcache[scid] = last_nword;
      probcache[scid] = maxprob;
      return(maxprob);
    } else {
      return (probcache[scid]);
    }
#endif /* UNIGRAM_FACTORING */
  } else {
    return(0.0);
#if 0
    maxprob = LOG_ZERO;
    for (sc=wchmm->state[node].sc;sc;sc=sc->next) {
      tmpprob = uni_prob(wchmm->ngram, sc->word);
      if (maxprob < tmpprob) maxprob = tmpprob;
    }
    return(maxprob);
#endif
  }

}

/* $B%N!<%I$KBP1~$9$k(Bfactoring$BCM$rJV$9(B($BC18l4V(B)
   factoring$B$,I,MW$J$9$Y$F$NC18l@hF,$N7W;;$r9T$J$C$F$+$i!$$=$NG[Ns$rJV$9(B */
/* For cross-word: return an array of factoring values for all word-start node
   when previous word context is 'lastword', consulting cache.
 */
#ifdef HASH_CACHE_IW
#define hashid(A) A % iw_cache_limit
#endif
LOGPROB *
max_successor_prob_iw(WCHMM_INFO *wchmm, WORD_ID lastword)
{
  int i, j, x, node;
  int last_nword;

  last_nword = wchmm->winfo->wton[lastword];
#ifdef HASH_CACHE_IW
  x = hashid(last_nword);
  if (iw_lw_cache[x] == last_nword) { /* cache hit */
    return(iw_sc_cache[x]);
  }
#else  /* full cache */
  if (iw_sc_cache[last_nword] != NULL) { /* cache hit */
    return(iw_sc_cache[last_nword]);
  }
  x = last_nword;
  /* cache mis-hit, calc probs and cache them as new */
#endif
  /* allocate cache memory */
  if (iw_sc_cache[x] == NULL) {
#ifdef UNIGRAM_FACTORING
    iw_sc_cache[x] = (LOGPROB *)mymalloc(sizeof(LOGPROB)*wchmm->isolatenum);
#else
    iw_sc_cache[x] = (LOGPROB *)mymalloc(sizeof(LOGPROB)*wchmm->startnum);
#endif
    if (iw_sc_cache[x] == NULL) { /* malloc failed */
      /* clear existing cache, and retry */
      max_successor_prob_iw_free();
      j_printf("inter-word LM cache (%dMB) rehashed\n",
	       (iw_cache_num * 
#ifdef UNIGRAM_FACTORING
		wchmm->isolatenum
#else
		wchmm->startnum
#endif
		) / 1000 * sizeof(LOGPROB) / 1000);
#ifdef UNIGRAM_FACTORING
      iw_sc_cache[x] = (LOGPROB *)mymalloc(sizeof(LOGPROB)*wchmm->isolatenum);
#else
      iw_sc_cache[x] = (LOGPROB *)mymalloc(sizeof(LOGPROB)*wchmm->startnum);
#endif
      if (iw_sc_cache[x] == NULL) { /* malloc failed again? */
	j_error("max_successor_prob_iw: cannot malloc\n");
      }
    }
  }

  /* calc prob for all startid */
#ifdef UNIGRAM_FACTORING
  for (j=0;j<wchmm->startnum;j++) {
    i = wchmm->start2isolate[j];
    if (i == -1) continue;
    node = wchmm->startnode[j];
    if (wchmm->state[node].fscore != LOG_ZERO) {
      /* should not be happen!!! below is just for debugging */
      j_error("No!!\n");
    } else {
#ifdef CLASS_NGRAM
      iw_sc_cache[x][i] = class_bi_prob_lr(ngram, last_nword, (wchmm->state[node].sc)->word);
#else
      iw_sc_cache[x][i] = bi_prob_lr(ngram, last_nword, (wchmm->state[node].sc)->word);
#endif
    }
  }
#else  /* ~UNIGRAM_FACTORING */
  for (i=0;i<wchmm->startnum;i++) {
    node = wchmm->startnode[i];
    iw_sc_cache[x][i] = calc_successor_prob(wchmm, last_nword, node);
  }
#endif
#ifdef HASH_CACHE_IW
  iw_lw_cache[x] = last_nword;
#endif

  return(iw_sc_cache[x]);
}


#else /* USE_DFA --- $B%+%F%4%jLZ$J$iITI,MW(B */

/* $B7hDjE*(B factoring: $B%N!<%I(B node $B$KD>A0C18lMzNr(B lastword $B$r;}$D%H!<%/%s$,(B
   $B%+%F%4%jBP@)Ls>e@\B3$G$-$k$+$I$&$+$r(B TRUE/FALSE$B$GJV$9!%(B*/
/* deterministic factoring: return whether a token with last word ID
   "lastword" can go into the branch node "node" by category-pair constraint.
*/
boolean
can_succeed(WCHMM_INFO *wchmm, WORD_ID lastword, int node)
{
  int lc;
  S_CELL *sc;

  /* return TRUE if at least one subtree word can connect */

  if (lastword == WORD_INVALID) { /* case at beginning-of-word */
    for (sc=wchmm->state[node].sc;sc;sc=sc->next) {
      if (dfa_cp_begin(wchmm->dfa, sc->word) == TRUE) return(TRUE);
    }
    return(FALSE);
  } else {
    lc = winfo->wton[lastword];
    for (sc=wchmm->state[node].sc;sc;sc=sc->next) {
      if (dfa_cp(wchmm->dfa, lc, sc->word) == TRUE) return(TRUE);
    }
    return(FALSE);
  }
}

#endif /* USE_DFA */


#endif /* CATEGORY_TREE */



















#ifdef CLASS_NGRAM

/*

  VERY EXPERIMENTAL, STILL UNDER CONSTRUCTION:
  PLEASE DO NOT USE FUNCTIONS BELOW.
  
  [Dynamic class N-gram handling]
*/
  
/*
  When apply:
  
   if wton[w] >= ngram->max_word_num; then
     wton[w] - ngram->max_word_num == ID of class N-gram 
   else
     wton[w] == ID of word N-gram

 */

static LOGPROB log_beta_w, log_beta_c; /* LM prob distibution coef. */
static WORD_ID *wtoc;		/* N-gram word ID -> class ID */
static LOGPROB *c_probsum;		/* sum of uniprob assigned by the class */
static LOGPROB *wtoc_prob;	/* interpolate prob for each word */
#ifndef CLASS_UNKNOWN_ONLY
static LOGPROB class_weight_log, class_weight_inv_log;
#endif

#define EP 2.302585093
/* try to use class N-gram for those whose N-gram entry does not
 exist in normal word N-gram */
void
make_class_ref(NGRAM_INFO *cinfo, WORD_INFO *winfo)
{
  WORD_ID w, c;
  char *cname, *buf, *p, *q;
  int i;
  int hitcount;


  true_max_num = ngram->max_word_num;
    
  buf = (char *)mymalloc(4096);

  wtoc = (WORD_ID *)mybmalloc(sizeof(WORD_ID) * ngram->max_word_num);
  
  /* regist class of each words for use as context */
  hitcount = 0;
  for(w=0;w<winfo->num;w++) {
    /* (1)$BF1$8C18l(B */
    c = ngram_lookup_word(cinfo, winfo->wname[w]);
    if (c == WORD_INVALID) {
      /* (2)$BI=5-(B+$BC18l(BID ($BFI$_H4$-(B) */
      if (strlen(winfo->wname[w]) >= 4096) {
	j_error("ERROR: make_class_ref: wname len exceed 4096!!\n");
      }
      strcpy(buf,winfo->wname[w]);
      p = strchr(buf, '+');
      q = strrchr(buf, '+');
      if (p && q && p != q) {
	memmove(p+1,q+1,buf+strlen(winfo->wname[w])-q);
	c = ngram_lookup_word(cinfo, buf);
	}
    }
    if (c == WORD_INVALID) {
      /* (3) $BC18l(BID */
      strcpy(buf,winfo->wname[w]);
      q = strrchr(buf, '+');
      if (q) {
	c = ngram_lookup_word(cinfo, q+1);
      }
    }
    if (c == WORD_INVALID) {
      /* (4) $BI=5-(B */
      p = strchr(buf, '+');
      if (p) {
	*p = '\0';
	c = ngram_lookup_word(cinfo, buf);
      }
    }
    if (c == WORD_INVALID) {
      /* $B%.%V%"%C%W(B */
      /*j_printerr("Warning: class N-gram entry for \"%s\" not found, use UNK class\n", winfo->wname[w]);*/
      c = cinfo->unk_id;
    } else {
      hitcount++;
    }
#if 0
    printf("%d (ngram=%d): %s [%s] belongs to [%s]\n", w, winfo->wton[w], ngram->wname[winfo->wton[w]], winfo->wname[w], cinfo->wname[c]);
#endif
    wtoc[winfo->wton[w]] = c;
  }
  printf("%d / %d hit\n", hitcount, winfo->num);

  /* set wtoc_prob */
  c_probsum = (LOGPROB *)mybmalloc(sizeof(LOGPROB)*cinfo->max_word_num);
  for(i=0;i<cinfo->max_word_num;i++) c_probsum[i] = 0.0;
  for(w=0;w<winfo->num;w++) {
    c = wtoc[winfo->wton[w]];
    if (c >= cinfo->max_word_num) {
      j_error("ERROR!!!\n");
    }
    c_probsum[c] += exp(uni_prob(ngram, winfo->wton[w])*EP);
  }
  for(i=0;i<cinfo->max_word_num;i++) {
    if (c_probsum[i] > 0.0) c_probsum[i] = log10(c_probsum[i]);
  }
  wtoc_prob = (LOGPROB *)mybmalloc(sizeof(LOGPROB) * ngram->max_word_num);
  for(w=0;w<winfo->num;w++) {
    c = wtoc[winfo->wton[w]];
    wtoc_prob[winfo->wton[w]] = uni_prob(ngram, winfo->wton[w]) - c_probsum[c];
  }
#if 0
  for(w=0;w<winfo->num;w++) {
    printf("%f %s-%s(%s)\n", wtoc_prob[winfo->wton[w]],cinfo->wname[wtoc[winfo->wton[w]]],ngram->wname[winfo->wton[w]], winfo->wname[w]);
  }
#endif

  free(buf);

#ifndef CLASS_UNKNOWN_ONLY
  if (class_weight > 0.0) {
    class_weight_log = log10(class_weight);
  } else {
    class_weight_log = LOG_ZERO;
  }
  if (1.0 - class_weight > 0.0) {
    class_weight_inv_log = log10(1.0 - class_weight);
  } else {
    class_weight_inv_log = LOG_ZERO;
  }
#endif
}

LOGPROB
class_uni_prob(NGRAM_INFO *ndata, WORD_ID w)
{
#ifdef CLASS_UNKNOWN_ONLY
  LOGPROB f;
#ifdef CLASS_UNKNOWN_ONLY_SCALED
  LOGPROB scale;
  scale = - log(1.0 - exp(uni_prob(ndata,ndata->unk_id)*EP) + exp(uni_prob(class_ngram, wtoc[ndata->unk_id])*EP))/EP ;
  if (w == ndata->unk_id) {
    f = uni_prob(class_ngram, wtoc[w]) + wtoc_prob[w] + scale;
  } else {
    f = uni_prob(ndata, w) + scale;
  }
  return(f);
#else
  if (w == ndata->unk_id) {
    f = uni_prob(class_ngram, wtoc[w]) + wtoc_prob[w];
  } else {
    f = uni_prob(ndata, w);
  }
  return(f);
#endif
#else
  /* linear interpolation for all (\beta = class_wright (option "-clw") */
  LOGPROB fw, fc;
  fc = uni_prob(class_ngram, wtoc[w]) + class_weight_log + wtoc_prob[w];
  fw = uni_prob(ndata, w) + class_weight_inv_log;
  return(log(exp(fc*EP)+exp(fw*EP))/EP);
#endif
}

LOGPROB
class_bi_prob_lr(NGRAM_INFO *ndata, WORD_ID w1, WORD_ID w2)
{
#ifdef CLASS_UNKNOWN_ONLY
  LOGPROB f;
#ifdef CLASS_UNKNOWN_ONLY_SCALED
  LOGPROB scale;
  scale = - log(1.0 - exp(bi_prob_lr(ndata, w1, ndata->unk_id)*EP) + exp(bi_prob_lr(class_ngram, wtoc[w1], wtoc[ndata->unk_id])*EP))/EP ;
  if (w2 == ndata->unk_id) {
    f = bi_prob_lr(class_ngram, wtoc[w1], wtoc[w2]) + wtoc_prob[w2] + scale;
  } else {
    f = bi_prob_lr(ndata, w1, w2) + scale;
  }
  return(f);
#else  
  if (w2 == ndata->unk_id) {
    f = bi_prob_lr(class_ngram, wtoc[w1], wtoc[w2]) + wtoc_prob[w2];
#if 0
    printf("[%s %s] - ", ngram->wname[w1], ngram->wname[w2]);
    printf("[%s %s %f]]\n",class_ngram->wname[wtoc[w1]], class_ngram->wname[wtoc[w2]], f);
#endif
  } else {
    f = bi_prob_lr(ndata, w1, w2);
  }
  return(f);
#endif
#else
  LOGPROB fw, fc;
  fc = bi_prob_lr(class_ngram, wtoc[w1], wtoc[w2]) + class_weight_log + wtoc_prob[w2];
  fw = bi_prob_lr(ndata, w1, w2) + class_weight_inv_log;
  return(log(exp(fc*EP)+exp(fw*EP))/EP);
#endif
}
LOGPROB
class_bi_prob_rl(NGRAM_INFO *ndata, WORD_ID w1, WORD_ID w2)
{
#ifdef CLASS_UNKNOWN_ONLY
  LOGPROB f;
#ifdef CLASS_UNKNOWN_ONLY_SCALED
  LOGPROB scale;
  scale = - log(1.0 - exp(bi_prob_rl(ndata, ndata->unk_id, w2)*EP) + exp(bi_prob_rl(class_ngram, wtoc[ndata->unk_id], wtoc[w2])*EP))/EP ;
  if (w1 == ndata->unk_id) {
    f = bi_prob_rl(class_ngram, wtoc[w1], wtoc[w2]) + wtoc_prob[w1] + scale;
  } else {
    f = bi_prob_rl(ndata, w1, w2) + scale;
  }
  return(f);
#else
  if (w1 == ndata->unk_id) {
    f = bi_prob_rl(class_ngram, wtoc[w1], wtoc[w2]) + wtoc_prob[w1];
  } else {
    f = bi_prob_rl(ndata, w1, w2);
  }
  return(f);
#endif
#else
  LOGPROB fw, fc;
  fc = bi_prob_rl(class_ngram, wtoc[w1], wtoc[w2]) + class_weight_log + wtoc_prob[w1];
  fw = bi_prob_rl(ndata, w1, w2) + class_weight_inv_log;
  return(log(exp(fc*EP)+exp(fw*EP))/EP);
#endif
}

LOGPROB
class_tri_prob_rl(NGRAM_INFO *ndata, WORD_ID w1, WORD_ID w2, WORD_ID w3)
{
#ifdef CLASS_UNKNOWN_ONLY
  LOGPROB f;
#ifdef CLASS_UNKNOWN_ONLY_SCALED
  LOGPROB scale;
  scale = - log(1.0 - exp(tri_prob_rl(ndata, ndata->unk_id, w2, w3)*EP) + exp(tri_prob_rl(class_ngram, wtoc[ndata->unk_id], wtoc[w2], wtoc[w3])*EP))/EP ;
  if (w1 == ndata->unk_id) {
    f = tri_prob_rl(class_ngram, wtoc[w1], wtoc[w2], wtoc[w3]) + wtoc_prob[w1] + scale;
  } else {
    f = tri_prob_rl(ndata, w1, w2, w3) + scale;
  }
  return(f);
#else
  if (w1 == ndata->unk_id) {
    f = tri_prob_rl(class_ngram, wtoc[w1], wtoc[w2], wtoc[w3]) + wtoc_prob[w1];
  } else {
    f = tri_prob_rl(ndata, w1, w2, w3);
  }
  return(f);
#endif
#else
  LOGPROB fw, fc;
  fc = tri_prob_rl(class_ngram, wtoc[w1], wtoc[w2], wtoc[w3]) + class_weight_log + wtoc_prob[w1];
  fw = tri_prob_rl(ndata, w1, w2, w3) + class_weight_inv_log;
  return(log(exp(fc*EP)+exp(fw*EP))/EP);
#endif
}
    
#endif
