/* Copyright (c) 1991-2002 Doshita Lab. Speech Group, Kyoto University */
/* Copyright (c) 2000-2002 Speech and Acoustics Processing Lab., NAIST */
/* Copyright (c) 2000-2002 IPA */
/*   All rights reserved   */

/* msock.h --- communicate with module */

#ifndef __SENT_MSOCK__
#define __SENT_MSOCK__

#include <sent/tcpip.h>

#define DEFAULT_MODULEPORT 10500	/* default server port number */

int module_send(char *fmt, ...);
boolean module_connect(int port);
boolean module_disconnect();
boolean module_is_connected();
boolean module_is_active();
boolean module_wants_terminate();
void module_reset_reload();
void msock_exec_command(char *command);
void msock_process_command();
void msock_check_and_process_command();
int msock_check_in_adin();


#endif /* __SENT_MSOCK__ */
