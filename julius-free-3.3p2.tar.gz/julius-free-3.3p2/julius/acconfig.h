
/* $Id: acconfig.h,v 1.1.1.1 2001/07/29 07:01:59 sumiyosi Exp $ */
/* Configuration result of defines with "J:" will be embeded in the binary */

/* executable name */
#undef EXECNAME

/* name of the product */
#undef PRODUCTNAME

/* version string */
#undef VERSION

/* setting when compiled (value of "--enable-setup=...") */
#undef SETUP

@TOP@
/* JULIAN related begin */
/* J: defined if compiled as DFA parser */
#undef USE_DFA

/* J: category-based tree lexicon on DFA parser */
#undef CATEGORY_TREE
/* JULIAN related end */

/* JULIUS related begin */
/* J: use 1-gram factoring on 1st pass */
#undef UNIGRAM_FACTORING

/* J: all words share a single root on lexicon tree (save memory of inter-word LM cache) */
#undef LOWMEM

/* J: separate hi-freq words from the lexicon tree */
#undef LOWMEM2
/* JULIUS related end */

/* J: use word-pair approximation on 1st pass */
#undef WPAIR

/* J: with WPAIR, keep only N-best path (option: "-nlimit N") */
#undef WPAIR_KEEP_NLIMIT

/* J: generate word graph on 1st pass */
#undef WORD_GRAPH

/* J: monophone tree lexicon on 1st pass (EXPERIMENTAL) */
#undef MONOTREE

/* J: handle inter-word triphone on 1st pass */
#undef PASS1_IWCD

/* J: strict inter-word triphone handling on 2nd pass */
#undef PASS2_STRICT_IWCD

/* J: enable score envelope beaming on 2nd pass scan */
#undef SCAN_BEAM

/* J: Gaussian pruning default = safe */
#undef GPRUNE_DEFAULT_SAFE

/* J: Gaussian pruning default = heuristic */
#undef GPRUNE_DEFAULT_HEURISTIC

/* J: Gaussian pruning default = beam */
#undef GPRUNE_DEFAULT_BEAM

/* J: enable progressive decoding with short pause segmentation */
#undef SP_BREAK_CURRENT_FRAME
